// utils/db.js — JSON-based persistent storage
const fs   = require('fs');
const path = require('path');

const DATA_DIR = path.join(__dirname, '..', 'data');

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

function load(file) {
  const fp = path.join(DATA_DIR, file);
  if (!fs.existsSync(fp)) return {};
  try { return JSON.parse(fs.readFileSync(fp, 'utf8')); }
  catch { return {}; }
}

function save(file, data) {
  const fp = path.join(DATA_DIR, file);
  fs.writeFileSync(fp, JSON.stringify(data, null, 2), 'utf8');
}

// ── Economy ──────────────────────────────────────────────────
function getEconomy() { return load('economy.json'); }
function saveEconomy(d) { save('economy.json', d); }

function getUser(userId) {
  const eco = getEconomy();
  if (!eco[userId]) eco[userId] = { coins: 0, xp: 0, level: 1, lastDaily: 0, lastWork: 0 };
  return eco[userId];
}

function saveUser(userId, data) {
  const eco = getEconomy();
  eco[userId] = data;
  saveEconomy(eco);
}

// ── Warns ─────────────────────────────────────────────────────
function getWarns() { return load('warns.json'); }
function saveWarns(d) { save('warns.json', d); }

function addWarn(guildId, userId, reason, mod) {
  const data = getWarns();
  const key = `${guildId}_${userId}`;
  if (!data[key]) data[key] = [];
  data[key].push({ reason, mod, date: Date.now() });
  saveWarns(data);
  return data[key].length;
}

function getWarnCount(guildId, userId) {
  const data = getWarns();
  return (data[`${guildId}_${userId}`] || []).length;
}

function clearWarns(guildId, userId) {
  const data = getWarns();
  delete data[`${guildId}_${userId}`];
  saveWarns(data);
}

function getWarnList(guildId, userId) {
  const data = getWarns();
  return data[`${guildId}_${userId}`] || [];
}

// ── Custom commands ───────────────────────────────────────────
function getCustomCmds() { return load('customcmds.json'); }
function saveCustomCmds(d) { save('customcmds.json', d); }

function addCustomCmd(guildId, name, response) {
  const d = getCustomCmds();
  if (!d[guildId]) d[guildId] = {};
  d[guildId][name.toLowerCase()] = response;
  saveCustomCmds(d);
}

function getCustomCmd(guildId, name) {
  const d = getCustomCmds();
  return d[guildId]?.[name.toLowerCase()] || null;
}

// ── Reminders ─────────────────────────────────────────────────
function getReminders() { return load('reminders.json'); }
function saveReminders(d) { save('reminders.json', d); }

module.exports = {
  getUser, saveUser,
  addWarn, getWarnCount, clearWarns, getWarnList,
  addCustomCmd, getCustomCmd, getCustomCmds,
  getReminders, saveReminders,
};
