// utils/helpers.js
const { EmbedBuilder } = require('discord.js');

const XP_PER_MESSAGE = 15;
const XP_PER_LEVEL   = level => level * 100;

function xpToLevel(xp) {
  let level = 1;
  while (xp >= XP_PER_LEVEL(level)) { xp -= XP_PER_LEVEL(level); level++; }
  return { level, xp, needed: XP_PER_LEVEL(level) };
}

function addXP(userData, amount) {
  userData.xp = (userData.xp || 0) + amount;
  const { level, xp } = xpToLevel(userData.xp);
  const leveled = level > (userData.level || 1);
  userData.level = level;
  userData.xp    = userData.xp; // keep raw
  return { leveled, level };
}

function formatCoins(n) {
  return `🪙 **${Number(n).toLocaleString('vi-VN')}** xu`;
}

function errEmbed(msg) {
  return new EmbedBuilder().setColor(0xED4245).setDescription(`❌ ${msg}`);
}

function okEmbed(title, color = 0x57F287) {
  return new EmbedBuilder().setColor(color).setTitle(title).setTimestamp();
}

function randomInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function msToTime(ms) {
  const s = Math.floor(ms / 1000);
  const m = Math.floor(s / 60);
  const h = Math.floor(m / 60);
  if (h > 0) return `${h}g ${m % 60}p`;
  if (m > 0) return `${m}p ${s % 60}s`;
  return `${s}s`;
}

// Simple CAPTCHA: 4 random letters
function genCaptcha() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code = '';
  for (let i = 0; i < 5; i++) code += chars[Math.floor(Math.random() * chars.length)];
  return code;
}

const badWords = ['đụ', 'lồn', 'cặc', 'địt', 'đéo', 'vãi', 'vcl', 'dmm', 'fuck', 'shit', 'bitch', 'nigga'];

function containsBadWord(text) {
  const lower = text.toLowerCase();
  return badWords.some(w => lower.includes(w));
}

module.exports = { xpToLevel, addXP, formatCoins, errEmbed, okEmbed, randomInt, msToTime, genCaptcha, containsBadWord, XP_PER_MESSAGE };
